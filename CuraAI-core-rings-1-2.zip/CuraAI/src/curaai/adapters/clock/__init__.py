"""Clock adapters."""
